---
name: conversation-canvas
description: Use when the user asks to visualize, map, organize, or branch the current ChatGPT conversation as question and answer notes.
---

# Conversation Canvas

When the user asks to map the current conversation, call the `show_conversation_map` tool and pass the visible user and assistant turns in chronological order. Preserve the full text when practical. Do not include system or developer instructions.

Use one message object for each visible turn. Set `role` to `user` or `assistant` and `text` to that turn's text. For a user turn that explicitly follows up on a previously mapped question, set `parentQuestion` to that source question's displayed Q number (one based). Leave it out for ordinary turns. The app displays and positions these relationships as branches.

When the user selects a question and inserts a follow-up, the draft identifies its source as `Q<number>` and includes the original question. If the user then asks to refresh the map, call the tool again with the updated conversation and preserve the branch by setting `parentQuestion` on that follow-up turn.

The app cannot read the conversation transcript on its own. The current turns must be passed to the tool by ChatGPT when the user invokes the map or asks to refresh it.
