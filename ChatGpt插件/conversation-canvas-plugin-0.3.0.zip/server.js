import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { dirname, join } from "node:path";

const root = dirname(fileURLToPath(import.meta.url));
const html = readFileSync(join(root, "app.html"), "utf8");
const resourceUri = "ui://conversation-canvas/map.html";
const inputSchema = {
  type: "object",
  properties: {
    title: { type: "string", description: "Optional title for this conversation." },
    messages: {
      type: "array",
      description: "Visible conversation turns in chronological order. Include user questions and assistant answers.",
      items: {
        type: "object",
        properties: {
          role: { type: "string", enum: ["user", "assistant"] },
          text: { type: "string" },
          parentQuestion: { type: "integer", minimum: 1, description: "For a follow-up branch, the displayed Q number of the source question." }
        },
        required: ["role", "text"]
      }
    }
  },
  required: ["messages"]
};

function write(message) {
  process.stdout.write(`${JSON.stringify(message)}\n`);
}

function response(id, result) {
  write({ jsonrpc: "2.0", id, result });
}

function error(id, code, message) {
  write({ jsonrpc: "2.0", id, error: { code, message } });
}

function normalize(args = {}) {
  const messages = Array.isArray(args.messages) ? args.messages : [];
  return {
    title: typeof args.title === "string" ? args.title.slice(0, 180) : "当前对话",
    messages: messages.slice(0, 500).map((m) => ({
      role: m?.role === "assistant" ? "assistant" : "user",
      text: typeof m?.text === "string" ? m.text : "",
      ...(Number.isInteger(m?.parentQuestion) && m.parentQuestion > 0 ? { parentQuestion: m.parentQuestion } : {})
    })).filter((m) => m.text.trim())
  };
}

function handle(message) {
  if (!message || typeof message !== "object") return;
  const { id, method, params = {} } = message;
  if (!method) return;
  if (method === "notifications/initialized" || method === "notifications/cancelled") return;
  if (method === "initialize") {
    response(id, {
      protocolVersion: params.protocolVersion || "2025-11-25",
      capabilities: { tools: { listChanged: false }, resources: { listChanged: false } },
      serverInfo: { name: "conversation-canvas", title: "对话便笺画布", version: "0.3.0" }
    });
    return;
  }
  if (method === "ping") { response(id, {}); return; }
  if (method === "tools/list") {
    response(id, { tools: [{
      name: "show_conversation_map",
      title: "显示对话便笺画布",
      description: "Display the current conversation as draggable question and answer notes. Include all visible user and assistant turns in chronological order. Use parentQuestion to attach a follow-up question to its source Q number.",
      inputSchema,
      _meta: { ui: { resourceUri, visibility: ["model", "app"] } },
      annotations: { readOnlyHint: true, openWorldHint: false }
    }] });
    return;
  }
  if (method === "resources/list") {
    response(id, { resources: [{ uri: resourceUri, name: "Conversation Canvas", mimeType: "text/html;profile=mcp-app" }] });
    return;
  }
  if (method === "resources/read") {
    if (params.uri !== resourceUri) { error(id, -32002, "Resource not found"); return; }
    response(id, { contents: [{ uri: resourceUri, mimeType: "text/html;profile=mcp-app", text: html }] });
    return;
  }
  if (method === "tools/call") {
    if (params.name !== "show_conversation_map") { error(id, -32602, "Unknown tool"); return; }
    const data = normalize(params.arguments);
    response(id, {
      content: [{ type: "text", text: `已整理 ${data.messages.length} 条对话消息。` }],
      structuredContent: data
    });
    return;
  }
  if (typeof id === "number" || typeof id === "string") error(id, -32601, `Method not found: ${method}`);
}

let buffer = "";
process.stdin.setEncoding("utf8");
process.stdin.on("data", (chunk) => {
  buffer += chunk;
  while (true) {
    const end = buffer.indexOf("\n");
    if (end < 0) break;
    const line = buffer.slice(0, end).trim();
    buffer = buffer.slice(end + 1);
    if (!line) continue;
    try { handle(JSON.parse(line)); }
    catch (err) { process.stderr.write(`Conversation Canvas MCP error: ${err?.stack || err}\n`); }
  }
});
